<?php
include_once("appConfig.php");
include("appHeader.php");
?>

<div class="w3-content w3-card">
  <h1 class="w3-center"><b><?php echo $app_name; ?></b> <?php echo $app_version; ?></h1>
  <h2 class="w3-center"><em><a href="./">START</a></em></h2>
</div>

<?php include_once "appFooter.php"; ?>

</body>
</html>